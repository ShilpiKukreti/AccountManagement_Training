﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace account_Managment
{
    internal class Accounts
    {
        public int accNo { get; set; }
        public string accName { get; set; }
        public string  accType { get; set; }
        public int accBalane { get; set; }
        public string accCity { get; set; }
        public string accIsActive { get; set; }

    }
}
