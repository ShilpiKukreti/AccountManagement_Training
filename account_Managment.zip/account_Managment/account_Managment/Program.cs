﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace account_Managment
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Dictionary<int, Accounts> dictionaryAccounts = new Dictionary<int, Accounts>();

            Accounts acc1 = new Accounts() { accNo = 1001, accName = "Shilpi", accType = "Savings", accBalane = 90000, accCity = "Kotdwara", accIsActive = "Yes" };
            Accounts acc2 = new Accounts() { accNo = 1002, accName = "Megha", accType = "Current", accBalane = 50000, accCity = "Mumbai", accIsActive = "No" };
            Accounts acc3 = new Accounts() { accNo = 1003, accName = "Meenakshee", accType = "Loan", accBalane = 20000, accCity = "Delhi", accIsActive = "Yes" };
            Accounts acc4 = new Accounts() { accNo = 1004, accName = "Archana", accType = "Savings", accBalane = 40000, accCity = "Gurgaon", accIsActive = "No" };
            Accounts acc5 = new Accounts() { accNo = 1005, accName = "Rahul", accType = "Current", accBalane = 10000, accCity = "Banglore", accIsActive = "Yes" };
            Accounts acc6 = new Accounts() { accNo = 1006, accName = "Ankit", accType = "Loan", accBalane = 100000, accCity = "Delhi", accIsActive = "Yes" };
            Accounts acc7 = new Accounts() { accNo = 1007, accName = "Swami", accType = "Savings", accBalane = 200000, accCity = "Delhi", accIsActive = "No" };
            Accounts acc8 = new Accounts() { accNo = 1008, accName = "Pranav", accType = "Loan", accBalane = 70000, accCity = "Kotdwara", accIsActive = "Yes" };
            Accounts acc9 = new Accounts() { accNo = 1009, accName = "Mukesh", accType = "Loan", accBalane = 90000, accCity = "Banglore", accIsActive = "No" };
            Accounts acc10 = new Accounts() { accNo = 1010, accName = "Swati", accType = "Current", accBalane = 25000, accCity = "Mumbai", accIsActive = "Yes" };
            Accounts acc11 = new Accounts() { accNo = 1011, accName = "Roshan", accType = "Savings", accBalane = 50000, accCity = "Delhi", accIsActive = "No" };
            Accounts acc12= new Accounts() { accNo = 1012, accName = "Deepanchal", accType = "Current", accBalane = 65000, accCity = "Kotdwara", accIsActive = "No" };
            Accounts acc13= new Accounts() { accNo = 1013, accName = "Priyanka", accType = "Loan", accBalane = 40000, accCity = "Mumbai", accIsActive = "Yes" };
            Accounts acc14 = new Accounts() { accNo = 1014, accName = "Suman", accType = "Current", accBalane = 100000, accCity = "Banglore", accIsActive = "Yes" };
            Accounts acc15= new Accounts() { accNo = 1015, accName = "Suresh", accType = "Savings", accBalane = 90000, accCity = "Delhi", accIsActive = "Yes" };
            Accounts acc16= new Accounts() { accNo = 1016, accName = "Shivali", accType = "Current", accBalane = 80000, accCity = "Mumbai", accIsActive = "Yes" };
            Accounts acc17= new Accounts() { accNo = 1017, accName = "Yogesh", accType = "Loan", accBalane = 100000, accCity = "Banglore", accIsActive = "No" };
            Accounts acc18= new Accounts() { accNo = 1018, accName = "Sanyam", accType = "Savings", accBalane = 85000, accCity = "Delhi", accIsActive = "Yes" };
            Accounts acc19= new Accounts() { accNo = 1019, accName = "Shikha", accType = "Current", accBalane = 90000, accCity = "Mumbai", accIsActive = "No" };
            Accounts acc20= new Accounts() { accNo = 1020, accName = "Bivas", accType = "Savings", accBalane = 100000, accCity = "Kotdwara", accIsActive = "Yes" };


            dictionaryAccounts.Add(acc1.accNo, acc1);
            dictionaryAccounts.Add(acc2.accNo, acc2);
            dictionaryAccounts.Add(acc3.accNo, acc3);
            dictionaryAccounts.Add(acc4.accNo, acc4);
            dictionaryAccounts.Add(acc5.accNo, acc5);
            dictionaryAccounts.Add(acc6.accNo, acc6);
            dictionaryAccounts.Add(acc7.accNo, acc7);
            dictionaryAccounts.Add(acc8.accNo, acc8);
            dictionaryAccounts.Add(acc9.accNo, acc9);
            dictionaryAccounts.Add(acc10.accNo, acc10);
            dictionaryAccounts.Add(acc11.accNo, acc11);
            dictionaryAccounts.Add(acc12.accNo, acc12);
            dictionaryAccounts.Add(acc13.accNo, acc13);
            dictionaryAccounts.Add(acc14.accNo, acc14);
            dictionaryAccounts.Add(acc15.accNo, acc15);
            dictionaryAccounts.Add(acc16.accNo, acc16);
            dictionaryAccounts.Add(acc17.accNo, acc17);
            dictionaryAccounts.Add(acc18.accNo, acc18);
            dictionaryAccounts.Add(acc19.accNo, acc19);
            dictionaryAccounts.Add(acc20.accNo, acc20);


            #region GetType

            List<string> lstAccountTypes = null;
            foreach (KeyValuePair<int, Accounts> accKeyValuePair in dictionaryAccounts)
            {
                Accounts acc = accKeyValuePair.Value;
                var key = accKeyValuePair.Key;

                if (lstAccountTypes == null)
                {
                    lstAccountTypes = new List<string>();
                }
                
                if (!lstAccountTypes.Contains(acc.accType))
                {
                    lstAccountTypes.Add(acc.accType);
                }
                else
                {
                    continue;
                }

            }

            #endregion

            #region Create Directories

            foreach (var accountType in lstAccountTypes)
            {           
                string root = "C:\\Temp\\" + accountType;
                if (Directory.Exists(root))
                {
                    Console.WriteLine("Folder already exists");
                    CreateFiles(dictionaryAccounts, root, accountType);

                }
                else
                {                  
                    Directory.CreateDirectory(root);
                    CreateFiles(dictionaryAccounts,root, accountType);                                                      
                }
                
            }

            #endregion

            #region call class Accounts_ADO

            Accounts_ADO accADO = new Accounts_ADO();
            accADO.InsertValuesToAccounts(dictionaryAccounts);

            #endregion
        }

        #region Create Files
        private static void CreateFiles(Dictionary<int,Accounts> dictionaryAccounts, string root, string accountType)
        {
            foreach (KeyValuePair<int, Accounts> accKeyValuePair in dictionaryAccounts)
            {
                Accounts acc = accKeyValuePair.Value;
                string filename = $"{acc.accNo}.txt";
                string path = root + "\\" + filename;
                FileStream f1 = null;
                if (acc.accType == accountType)
                {
                    f1 = new FileStream(path, FileMode.Create);
                    using (StreamWriter sw = new StreamWriter(f1))
                    {
                        sw.WriteLine(acc.accNo + "," + acc.accName + "," + acc.accType + "," + acc.accBalane + "," + acc.accCity + "," + acc.accIsActive);
                    }
                }
            }
        }

        #endregion
    }
}
