﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace account_Managment
{
    internal class Accounts_ADO
    {
        
        SqlConnection conn = null;
        SqlCommand cmd = null;
        public void InsertValuesToAccounts(Dictionary<int, Accounts> _dictionaryAccounts)
        {

            try
            {
                conn = new SqlConnection(@"Server = LTIN392363 ;Database= accountsDB ;Integrated Security= True ");
                conn.Open();
                // conn = new SqlConnection(@"Server = LTIN392363 ; Database = TrainingDB; Integrated Security = True");

                foreach (KeyValuePair<int, Accounts> accKeyValue in _dictionaryAccounts)
                {
                    cmd = new SqlCommand("insert into Accounts values(@accNO,@accName,@accType,@accBalance,@accCity,@accIsActive)", conn);
                    Accounts acc = accKeyValue.Value;

                    int accNo = Convert.ToInt32(acc.accNo);
                    string accName =Convert.ToString(acc.accName);
                    string accType = Convert.ToString(acc.accType);
                    int accBalance = Convert.ToInt32(acc.accBalane);
                    string accCity =Convert.ToString(acc.accCity);
                    string accIsActive =Convert.ToString(acc.accIsActive);

                    cmd.Parameters.AddWithValue("@accNO", accNo);
                    cmd.Parameters.AddWithValue("@accName", accName);
                    cmd.Parameters.AddWithValue("@accType", accType);
                    cmd.Parameters.AddWithValue("@accBalance", accBalance);
                    cmd.Parameters.AddWithValue("@accCity", accCity);
                    cmd.Parameters.AddWithValue("@accIsActive", accIsActive);

                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Data Insert Successfully");
                    Console.ReadLine();

                }
            }

            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
                cmd.Dispose();
                conn.Dispose();

            }

        }


    }
}   

